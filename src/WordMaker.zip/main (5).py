# create a list of 10 prefixes
prefixes = ["Anti","De","Dis","En","Fore","Inter", "Mid", "Mis", "Non", "Over", "Pre","Co", "Hyper","Ultra", "Extra", "Micro", "Mini", "Semi","Sub","Ex"]
preDef = [ "; Opposed to", "; In", "; Before", "; Front","; Within", "; Middle", "; Not at all", "; Above", "; Before", "; From","; Extremely","; Very extremely", "; More than anything", "; Very small", "; Small", "; Half", "; Below", "; Except"]
# create a list of 10 suffixes
suffixes = ["age","ful", "ing", "less", "ment", "ness", "y", "ate", "ify", "ize","acy"]
suffDef = [ "old.", "full of.", "less than.", "characterized by.", "not.", "used as a noun.", "made of.", "change.", "made into.", "a state of being in which something is different.", "a state of being in which something is different.", "an adjective or adverb that describes a noun or."]


word_root = ["usual", "write", "value","view","help","sleep","love","hope", "care", "bear", "being", "born", "came", "come", "done","grow", "gave", "gone", "know", "made", "mean", "meet"]
rootDef = ["common", "record", "worth" ,"look at", "assist" ,"rest", "adore", "hopeful", "attentive", "bear flowers", "being present", "born of" ,"come from somewhere", "finished" ,"grow up on", "give" ,"gone away from", "know", "past and past participle of make", "mean to", "touch or join"]
print("Welcome to the application Word Maker !")
print("How many words would you like to generate ?")
user_input = int(input("Enter input:"))
number_of_word = user_input
import random  # Move the import statement here
while number_of_word > 0:  # Add a valid condition here
  random_prefix = random.choice(prefixes)
  random_suffix = random.choice(suffixes)
  random_word_root = random.choice(word_root)
  print(random_prefix + random_word_root + random_suffix + " " + random.choice(preDef) + " " + random.choice(rootDef) + " " + random.choice(suffDef))
  number_of_word -= 1  # Decrement the number_of_word at the end of the loop
  
  
